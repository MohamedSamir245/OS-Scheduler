
// Testing Push;

// struct Node {
//     struct Process* element;
//     struct Node* next;
// };

// void Node(struct Node *self,struct Process* e)
//     {
//         self->element = e;
//         self->next=NULL;
//     }

// struct Queue
// {
//     struct Node* head;
//     struct Node* tail;
// };

// void dequeue(struct Queue* self)
//     {
//         struct Node* temp=self->head;
//         self->head=self->head->next;
//         free(temp);
//     }

// void eneque(struct Queue* self,struct Node* newP)
// {
//     // HPF
//     if(algo==0)
//     {
//         struct Node* temp=self->head;
//         struct Node* previous=self->head;
//         if(!temp)
//         {
//             // first node
//         }
//         while(temp && newP->element->priority >= temp->element->priority)
//         {
//             temp=temp->next;
//         }
//         if(temp)
//         {
            
//         }

        
//     }
//     // SRTN
//     else if(algo==1)
//     {

//     }
//     // RR
//     else if(algo==2)
//     {

//     }
    
// }