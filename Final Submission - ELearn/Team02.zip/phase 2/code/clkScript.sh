gcc clk.c -o clk.out
./clk.out

