
#include "headers.h"

struct treeNode *Root = NULL;

void main()
{
    Root = createTreeNode(0, 1024, 0, (struct treeNode *)NULL);

    // int currSize=0;
    // tn={-1,nStart,nSize,nPosition,NULL,NULL,NULL};
    //,tempNode;
    // tempNode={-1,0,0,0};
    // struct treeNode* arr[1024];
    // arr[0]=Root;
    // currSize+=1;
    //  currSize = &tmp;
    // tmp = 1;

    // printf("%d",currSize);

    // array[0] = createTreeNode(0, 1024, 0, NULL);

    int psize1 = 300;
    int psize2 = 200;
    int psize3 = 256;
    int psize4 = 512;

    // printf("Allocated = %d, Now size is %d", allocateMemory(arr, currSize, psize1, 1), currSize);
    //  printf("Allocated = %d, Now size is %d", allocateMemory(array, currSize, psize2, 2), currSize);
    //  printf("Allocated = %d, Now size is %d", allocateMemory(array, currSize, psize3, 3), currSize);
    //  printf("Allocated = %d, Now size is %d", allocateMemory(array, currSize, psize4, 4), currSize);
}
