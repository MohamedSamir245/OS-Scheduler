
gcc scheduler.c -o scheduler
./scheduler
